import 'dart:developer';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

class BGController extends GetxController{
  apicall() async{
    var response = await http.get(Uri.parse("https://dummyjson.com/products/1"));
    log("response = ${response.body}");
  }
}