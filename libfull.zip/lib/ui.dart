import 'package:flutter/material.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'bgservicd.dart';

class MYwidget extends StatefulWidget {
  const MYwidget({super.key});

  @override
  State<MYwidget> createState() => _MYwidgetState();
}

class _MYwidgetState extends State<MYwidget> {
  final service = FlutterBackgroundService();
  bool isRunning = false;

  @override
  void initState() {
    super.initState();
    _checkServiceStatus(); // Updates initial button label
  }

  Future<void> _checkServiceStatus() async {
    isRunning = await service.isRunning();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () async {
                await initilizeservice();
                await service.startService(); // Start it first
                service.invoke("setAsForeground");
                await _checkServiceStatus(); // Update state
              },
              child: const Text("Foreground"),
            ),
            ElevatedButton(
              onPressed: () async {
                if (isRunning) {
                  service.invoke("stopService");
                  isRunning = false;
                  setState(() {});
                }
              },
              child: const Text("Stop Service"),
            ),
            const SizedBox(height: 20),
            Text("Service is ${isRunning ? "Running" : "Stopped"}"),
          ],
        ),
      ),
    );
  }
}
