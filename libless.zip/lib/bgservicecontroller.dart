import 'dart:developer';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

import 'bgservicd.dart';

class BGController extends GetxController{
  final service = FlutterBackgroundService();
  RxBool isRunning = false.obs;
  apicall() async{
    var response = await http.get(Uri.parse("https://dummyjson.com/products/1"));
    log("response = ${response.body}");
  }
  Future<void> checkServiceStatus() async {
    isRunning.value = await service.isRunning();
  }

  @override
  void onInit() async{
    checkServiceStatus();
    await initilizeservice();
    super.onInit();
  }
}