import 'package:background/bgservicecontroller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'bgservicd.dart';

class MYwidget extends StatelessWidget {
  const MYwidget({super.key});
  @override
  Widget build(BuildContext context) {
    var bgcontroller = Get.put(BGController());
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () async {
                await initilizeservice();
                await bgcontroller.service.startService(); // Start it first
                bgcontroller.service.invoke("setAsForeground");
                await bgcontroller.checkServiceStatus(); // Update state
              },
              child: const Text("Foreground"),
            ),
            ElevatedButton(
              onPressed: () async {
                if (bgcontroller.isRunning.value) {
                  bgcontroller.service.invoke("stopService");
                  bgcontroller.isRunning.value = false;
                }
              },
              child: const Text("Stop Service"),
            ),
            const SizedBox(height: 20),
            Obx(() => Text("Service is ${bgcontroller.isRunning.value ? "Running" : "Stopped"}"),),
          ],
        ),
      ),
    );
  }
}
